before runnning the streamlit app
in command prompt do 
pip freeze > requirements.txt
or
pip install streamlit pandas joblib os

To run Streamlit application:
python -m streamlit run app4.py