import joblib
import pandas as pd
import streamlit as st
from streamlit_option_menu import option_menu
import os
import matplotlib.pyplot as plt
from PIL import Image
from streamlit_javascript import st_javascript

# Load the saved model
log_reg_loaded = joblib.load(r'C:\Users\prasa\OneDrive\Desktop\infosys_online\website\random_forest.pkl')

# Transaction types for dropdown
transaction_types = {
    "Select Transaction Type": -1,
    "Cash-in": 0,
    "Cash-out": 1,
    "Debit": 2,
    "Payment": 3,
    "Transfer": 4,
    "Deposit": 5,
}

# Create or load transaction history
history_path = "transactions_history.csv"
if not os.path.exists(history_path):
    pd.DataFrame(columns=["Transaction Type", "Amount", "Old Balance", "New Balance", "Prediction"]).to_csv(history_path, index=False)

# Set Streamlit page configuration
st.set_page_config(page_title="Fraud Detection System", layout="wide")
# image_path = "C:/Users/prasa/OneDrive/Desktop/infosys_online/website/top1.png"

# # Open the image using PIL
# img = Image.open(image_path)

# # Resize the image (set desired width and height)
# img = img.resize((600, 100))  # Set width=800px and height=400px

# # Display the resized image
# st.image(img)
# App-wide Background Style
st.markdown("""
    <style>
        body {
            background-color: #051856;
            color: white;
            # font-size:1.5em;
        }
        .stImage{
            position:center;
        }
        .stApp {
            # font-size:3em;
            # background-color:#171717;
            # background-color:#403B77;
            # background-image: linear-gradient( 109.6deg,  rgba(112,246,255,0.33) 11.2%, rgba(221,108,241,0.26) 42%, rgba(229,106,253,0.71) 71.5%, rgba(123,183,253,1) 100.2% );
            # background-image:url(r"C:\\Users\prasa\OneDrive\Desktop\infosys_online\website\bg2.jpg");
            # background-image: url("https://img.freepik.com/free-vector/winter-blue-pink-gradient-background-vector_53876-117276.jpg?t=st=1732336073~exp=1732339673~hmac=b80218f5d3c38ed7471744df9e3643379a79847b8679731d0282d6a841b8e5ec&w=996");
            # background-image: url("https://s3.ap-south-1.amazonaws.com/img1.creditmantri.com/community/article/steps-to-activate-sbi-debit-card-for-online-transaction.jpg");
            # background:white;
            # background-color: #0093E9;
# background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);

            # background-color: #FFFFFF;
# background-image: linear-gradient(180deg, #FFFFFF 0%, #6284FF 50%, #FF0000 100%);
            color:white;

            # background-image: url('https://www.oktopayments.com/wp-content/uploads/2023/11/online-payment-methods-meaning.png'); /* Replace with your image URL */
            # background-size: cover; /* Ensures the image covers the entire screen */
            # background-repeat: no-repeat; /* Prevents tiling */
            # background-position: center; /* Centers the image */
            # background: rgb(63,94,251);
            # background: radial-gradient(circle, rgba(63,94,251,1) 0%, rgba(252,70,107,1) 100%);
            # color: white; /* Adjust text color for readability */
            
        }
        .morphism-opacity {
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2); /* White with opacity */
            backdrop-filter: blur(10px); /* Blurring effect */
            border: 1px solid rgba(255, 255, 255, 0.3); /* Glass border */
            border-radius: 20px; /* Rounded corners */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            # opacity:70%;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            font-family: Arial, sans-serif;
            font-size: 18px;
            margin:10px;
            padding-top:1px;
            padding-left:15px;
            padding-right:15px;
            # padding-down:0px;
            transition: transform 0.2s ease;
        }
        .morphism-opacity:hover{
            transform:translateY(-4px);
            scale:1.01;
        }
        .custom-card {
        font-size: 1.2rem;
        background: rgba(255, 255, 255, 0.2); /* White with opacity */
        backdrop-filter: blur(10px); /* Blurring effect */
        border: 1px solid rgba(255, 255, 255, 0.3); /* Glass border */
        border-radius: 20px; /* Rounded corners */
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        # background-color: var(--card-bg);
        # border-radius: 10px;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        transition: transform 0.3s ease;
    }

    .custom-card:hover {
        transform: translateY(-5px);
    }
        .card {
            background-color: white;
            border-radius: 15px;
            padding: 25px;
            margin: 10px 0;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.15);
            background: rgba( 255, 255, 255, 0.25 );
            box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );
            backdrop-filter: blur( 4px );
            -webkit-backdrop-filter: blur( 4px );
            border-radius: 10px;
            border: 1px solid rgba( 255, 255, 255, 0.18 );
        }
        div.stButton > button {
        width:90%;
        --border-color: linear-gradient(-45deg, #ffae00, #7e03aa, #00fffb);
        --border-width: 0.125em;
        --curve-size: 0.5em;
        --blur: 30px;
        --bg: #080312;
        --color: #afffff;
        color: var(--color);
        cursor: pointer;
        position: relative;
        isolation: isolate;
        display: inline-grid;
        place-content: center;
        padding: 0.5em 1.5em;
        font-size: 1.2em;
        border: 0;
        text-transform: uppercase;
        box-shadow: 10px 10px 20px rgba(0, 0, 0, 0.6);
        clip-path: polygon(
            0% var(--curve-size),
            var(--curve-size) 0,
            100% 0,
            100% calc(100% - var(--curve-size)),
            calc(100% - var(--curve-size)) 100%,
            0 100%
        );
        transition: color 250ms;
        }

        div.stButton > button::after,
        div.stButton > button::before {
        content: "";
        position: absolute;
        inset: 0;
        }

        div.stButton > button::before {
        background: var(--border-color);
        background-size: 300% 300%;
        animation: move-bg7234 5s ease infinite;
        z-index: -2;
        }

        @keyframes move-bg7234 {
        0% {
            background-position: 31% 0%;
        }
        50% {
            background-position: 70% 100%;
        }
        100% {
            background-position: 31% 0%;
        }
        }

        div.stButton > button::after {
        background: var(--bg);
        z-index: -1;
        clip-path: polygon(
            var(--border-width) calc(var(--curve-size) + var(--border-width) * 0.5),
            calc(var(--curve-size) + var(--border-width) * 0.5) var(--border-width),
            calc(100% - var(--border-width)) var(--border-width),
            calc(100% - var(--border-width)) calc(100% - calc(var(--curve-size) + var(--border-width) * 0.5)),
            calc(100% - calc(var(--curve-size) + var(--border-width) * 0.5)) calc(100% - var(--border-width)),
            var(--border-width) calc(100% - var(--border-width))
        );
        transition: clip-path 500ms;
        }

        div.stButton > button:where(:hover, :focus)::after {
        clip-path: polygon(
            calc(100% - var(--border-width)) calc(100% - calc(var(--curve-size) + var(--border-width) * 0.5)),
            calc(100% - var(--border-width)) var(--border-width),
            calc(100% - var(--border-width)) var(--border-width),
            calc(100% - var(--border-width)) calc(100% - calc(var(--curve-size) + var(--border-width) * 0.5)),
            calc(100% - calc(var(--curve-size) + var(--border-width) * 0.5)) calc(100% - var(--border-width)),
            calc(100% - calc(var(--curve-size) + var(--border-width) * 0.5)) calc(100% - var(--border-width))
        );
        transition: 200ms;
        }

        div.stButton > button:where(:hover, :focus) {
        color: #fff;
        }
    #     div.stButton > button {
    #         # visibility:hidden;
    #         width:90%;
    #         height:55px;
    #         position: absolute;
    # #   opacity: 0;
    #         transform:translate(10px,-730px);
    #     }
    #     div.stButton > button {
    #     appearance: none;
    #         color: greenyellow;
    #     background-color: ;
    #     border: 2px solid #1A1A1A;
    #     border-radius: 15px;
    #     box-sizing: border-box;
    #     color: #3B3B3B;
    #     cursor: pointer;
    #     display: inline-block;
    #     font-family: Roobert, -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, 
    #                  "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
    #     font-size: 16px;
    #     font-weight: 600;
    #     line-height: normal;
    #     margin: 0;
    #     min-height: 60px;
    #     min-width: 0;
    #     outline: none;
    #     padding: 16px 24px;
    #     text-align: center;
    #     text-decoration: none;
    #     transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
    #     user-select: none;
    #     -webkit-user-select: none;
    #     touch-action: manipulation;
    #     width: 100%;
    #     will-change: transform;
    # }

    # div.stButton > button:disabled {
    #     pointer-events: none;
    # }

    # div.stButton > button:hover {
    #     color: #fff;
    #     background-color: #1A1A1A;
    #     box-shadow: rgba(0, 0, 0, 0.25) 0 8px 15px;
    #     transform: translateY(-2px);
    # }

    # div.stButton > button:active {
    #     box-shadow: none;
    #     transform: translateY(0);
    # }
#         div.stButton > button {
#         background-color: #F4D03F;
# background-image: linear-gradient(132deg, #F4D03F 0%, #16A085 100%);

#         color: white; /* Text color */
#         border: none; /* Remove border */
#         border-radius: 8px; /* Rounded corners */
#         padding: 10px 20px; /* Button padding */
#         font-size: 30px; /* Font size */
#         font-weight: bold; /* Font weight */
#         cursor: pointer; /* Pointer cursor */
#         # cursor: progress;
#     }
    

#     /* Optional: Hover effect for better interaction */
#     div.stButton > button:hover {
#         background-image: linear-gradient(160deg, #80D0C7 0%, #0093E9 100%);
#         box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
#     }
        # .stButton>button {
        #     background-color: #007bff;
        #     color: white;
        #     border: none;
        #     padding: 10px 20px;
        #     border-radius: 5px;
        #     font-size: 16px;
        # }
        # .stButton>button:hover {
        #     background-color: #0056b3;
        # }
        .fraud {
            # transform:translate(10px,-660px);
            
            display: flex;
    justify-content: center;  /* Horizontally centers the content */
    # align-items: center;
            align-items:center;
            background-color: lightcoral;
            color: white;
            height:40px;
            width:200%;
            border-radius:5px;
        }
        .not-fraud {
            # transform:translate(10px,-660px);
            
            display: flex;
    justify-content: center;  /* Horizontally centers the content */
    # align-items: center;
            align-items:center;
            background-color: lightgreen;
            color: white;
            width:200%;
            height:40px;
            border-radius:5px;
        }
        div.stAlert {
            # transform:translate(10px,-660px);
            
            background-color: #f1004b;
background-image: linear-gradient(180deg, #f1004b 0%, #FF0000 33%, #ff0000 66%);

                        # background: rgb(131,58,180);
                        # background: linear-gradient(90deg, rgba(131,58,180,1) 0%, rgba(253,29,29,1) 50%, rgba(252,176,69,1) 100%) !important;
                        font-size:2em;
                        width:200%;
                        color: white;
                        blur:10%;
                        border-radius: 10px;
                        padding: 10px;
                    }
        .error{
            background-color: #f1004b;
background-image: linear-gradient(180deg, #f1004b 0%, #FF0000 33%, #ff0000 66%);

                        # background: rgb(131,58,180);
                        # background: linear-gradient(90deg, rgba(131,58,180,1) 0%, rgba(253,29,29,1) 50%, rgba(252,176,69,1) 100%) !important;
                        font-size:1em;
                        width:100%;
                        color: white;
                        blur:10%;
                        border-radius: 10px;
                        padding: 10px;
        }
        label {
        color: white !important;
        # font-size:1.2em;
        font-size: 60px !important; /* Adjust font size as needed */
    }
    /* Optional: Change the font color of specific sections or titles */
    .section-title {
        color: whtite;        
    }
    .fixed-image {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 9999;
        }
        .content {
            margin-top: 120px;  /* Adjust this value based on the height of your image */
        }
    </style>
""", unsafe_allow_html=True)


st.markdown('<img src="{./top1.png}" class="fixed-image">', unsafe_allow_html=True)
# Horizontal Menu with updated styles
selected = option_menu(
    menu_title=None,
    options=["Home", "Single Transaction", "Bulk Upload", "Transaction History", "About"],
    icons=["house", "currency-dollar", "upload", "list-task", "info-circle"],
    menu_icon="cast",
    default_index=0,
    orientation="horizontal",
    styles={
        "container": {"padding": "0!important", "background-color": "#f8f9fa","border-radius":"60px","margin":"0!important"},
        "icon": {"color": "black", "font-size": "22px"},
        "nav-link": {
            "font-size": "20px",
            "color": "black",
            "text-align": "center",
            "margin": "0px",
            "padding": "10px",
            "--hover-color": "#e9ecef",
        },
        # "nav-link-selected": {"background: rgb(63,94,251);background: radial-gradient(circle, rgba(63,94,251,1) 0%, rgba(252,70,107,1) 100%);background-color": "#007bff", "color": "black"},
        "nav-link-selected": {"background: radial-gradient(circle at 1.2% 5.3%, rgb(255, 85, 166) 0%, rgb(255, 154, 98) 100.2%);background-color": "pink", "color": "black","border-radius":"25px","scale":"0.85"},
    },
)

if "transaction_type" not in st.session_state:
    st.session_state.transaction_type = "Select Transaction Type"
if "transaction_amount" not in st.session_state:
    st.session_state.transaction_amount = 0.0
if "old_balance" not in st.session_state:
    st.session_state.old_balance = 0.0
if "new_balance" not in st.session_state:
    st.session_state.new_balance = 0.0


# Pages Logic
if selected == "Home":


    st.markdown('''
                <div class="morphism-opacity">
                <h1>Online Payment Fraud Detection</h1>
                </div>
                ''', unsafe_allow_html=True)
    st.markdown("""
            <div class="morphism-opacity">
        <div style="font-size: 18px; line-height: 1.8;">
            Welcome to the <b>Online Payment Fraud Detection Tool</b>! This application is designed to safeguard your financial transactions by identifying and preventing fraudulent activities using cutting-edge machine learning technologies. 
        </div>
        </div>""",unsafe_allow_html=True)
    col1,col2 = st.columns([1,1])
    with col1:

        # st.markdown('<h1>Online Payment Fraud Detection</h1>', unsafe_allow_html=True)
        st.markdown("""
        <div class="morphism-opacity">
        <h2>What Can This Tool Do?</h2>
        </div>
        <div class="morphism-opacity">
        <ul style="font-size: 16px; line-height: 1.8;">
            <li><b>Detect Fraud in Real-Time:</b> Analyze individual transactions instantly to determine their legitimacy.</li>
            <li><b>Bulk Transaction Analysis:</b> Upload transaction datasets to detect anomalies across multiple records simultaneously.</li>
            <li><b>Track Transaction History:</b> Maintain a detailed log of past transactions for review and compliance purposes.</li>
            <li><b>Educate and Inform:</b> Access comprehensive resources to understand fraud trends and how to protect yourself.</li>
        </ul>
        </div>
        <div class="morphism-opacity">
        <h2>How It Works:</h2>
        </div>
        <div class="morphism-opacity">
        <ol style="font-size: 16px; line-height: 1.8;">
            <li><b>Data Input:</b> Provide transaction data manually or upload a file containing multiple transactions.</li>
            <li><b>Fraud Detection Analysis:</b> The system uses machine learning algorithms trained on historical fraud data to flag suspicious transactions.</li>
            <li><b>Output Report:</b> Receive a detailed report highlighting potential fraudulent activities with actionable insights.</li>
        </ol>
        </div>
        <div class="morphism-opacity">
        <h2>Why Choose This Tool?</h2>
        </div>
        <div class="morphism-opacity">
        <p style="font-size: 16px; line-height: 1.8;">
            Fraudulent transactions not only cause financial losses but also erode trust in digital platforms. Our tool offers:
        </p>
        </div>
        <div class="morphism-opacity">
        <ul style="font-size: 16px; line-height: 1.8;">
            <li><b>High Accuracy:</b> Machine learning algorithms continuously learn and adapt to new fraud patterns.</li>
            <li><b>User-Friendly Interface:</b> Designed for simplicity and ease of use, enabling anyone to detect fraud effortlessly.</li>
            <li><b>Data Security:</b> Built with robust encryption and compliance with industry standards to protect your sensitive data.</li>
        </ul>
        </div>
        <div class="morphism-opacity">
        <h2>Steps to Get Started:</h2>
        </div>
        <div class="morphism-opacity">
        <p style="font-size: 16px; line-height: 1.8;">
            Follow these easy steps to begin using the Online Payment Fraud Detection Tool:
        </p>
        </div>
        <div class="morphism-opacity">
        <ol style="font-size: 16px; line-height: 1.8;">
            <li>Navigate to the <b>Fraud Detection</b> tab.</li>
            <li>Input transaction details or upload your dataset.</li>
            <li>Click <b>Analyze</b> to view results.</li>
            <li>Explore the <b>Tips</b> section to learn about secure online payment practices.</li>
        </ol>
        </div>
        """, unsafe_allow_html=True)
        with col2:
            st.markdown('<img style="margin-left:10px;margin-right:auto" src="https://miro.medium.com/v2/resize:fit:2000/1*M2dT90tDTwIYTQcNPkcmvg.jpeg" alt="Fraud Detection">', unsafe_allow_html=True)
            
            st.write("""
            
            
            """)
            st.markdown('<img style="margin-left:10px;margin-right:auto" src="https://www.fraudlabspro.com/resources/wp-content/uploads/2022/10/flp-oct-top-img.jpg" alt="Fraud Detection">', unsafe_allow_html=True)
            st.write("""
            
            
            """)
            st.markdown('<img style="margin-left:10px;margin-right:auto" src="https://images.moneycontrol.com/static-mcnews/2024/10/20241001065852_idendity-verification.jpg" alt="Fraud Detection">', unsafe_allow_html=True)
            
            st.markdown('''<div class="morphism-opacity">
                <h2>Stay Ahead of Fraud:</h2>
                </div>
                <div class="morphism-opacity">
                <p style="font-size: 16px; line-height: 1.8;">
                    Fraud prevention starts with awareness and proactive measures. By leveraging advanced technologies, 
                    this tool empowers you to stay one step ahead of cybercriminals. Whether you're an individual or a business, 
                    safeguarding your transactions has never been more important.
                </p>
                </div>''', unsafe_allow_html=True)

            # image_path = "home1.png"

            # # Open the image using PIL
            # img = Image.open(image_path)

            # # Resize the image (set desired width and height)
            # img = img.resize((400, 600))  # Set width=800px and height=400px

            # # Display the resized image
            # st.image(img)
    col1, col2, col3, col4, col5 = st.columns(5)
        
    with col1:
        st.markdown("""
                    <a href="https://www.datavisor.com/wiki/real-time-monitoring/" target="_blank" style="text-decoration: none;">
            <div class="custom-card">
                <h3 style="color: white;">Real-time Detection</h3>
                <img src="https://tinybird-blog.ghost.io/content/images/2024/03/Build-a-real-time-anomaly-detection-algorithm--with-SQL---OpenGraph-min-1.png" style="width: 100%; border-radius: 5px; margin: 1rem 0;">
                <p style="color: white;font-size: 1.2rem;">
                    Our system processes transactions in real-time, providing instant fraud detection and alerts.
                    <br><u><b>Click me to learn more</b></u>
                </p>
            </div> </a>
        """, unsafe_allow_html=True)
        
    with col2:
        st.markdown("""
                    <a href="https://www.fraud.com/post/5-fraud-detection-methods-for-every-organization" target="_blank" style="text-decoration: none;">
            <div class="custom-card">
                <h3 style="color: white;">Strategies & Technologies</h3>
                <img src="https://media.licdn.com/dms/image/v2/D5612AQESW_Wi8N3Q5g/article-cover_image-shrink_600_2000/article-cover_image-shrink_600_2000/0/1688418234971?e=2147483647&v=beta&t=5A-1uSGsUQ3w-cYJRoW10SMohLyZzUHMjOVkewCB3kM" style="width: 100%; border-radius: 5px; margin: 1rem 0;">
                <p style="color: white;font-size: 1.2rem;">
                    Include Machine Learning, Artificial Intelligence, Blockchain-based secure payment processing.
                    <br><u><b>Click me to learn more</b></u>
                </p>
            </div> </a>
        """, unsafe_allow_html=True)

    with col3:
        st.markdown("""
                    <a href="https://www.fraud.com/post/fraud-prevention" target="_blank" style="text-decoration: none;">
            <div class="custom-card">
                <h3 style="color: white;">Fraud Prevention</h3>
                <img src="https://www.cumanagement.com/sites/default/files/2023-03/fraud-prevention-key-keyboard-finger.jpg" style="width: 100%; border-radius: 5px; margin: 1rem 0;">
                <p style="color: white;font-size: 1.2rem;">
                    Involves measures using Artificial Intelligence, Machine Learning, biometrics to detect and prevent fraudulent activities.
                    <br><u><b>Click me to learn more</b></u>
                </p>
            </div> </a>
        """, unsafe_allow_html=True)

    with col4:
        st.markdown("""
                    <a href="https://www.fraud.com/post/fraud-data-analytics" target="_blank" style="text-decoration: none;">
            <div class="custom-card">
                <h3 style="color: white;">Advanced Analytics</h3>
                <img src="https://learn.g2.com/hubfs/what-is-advanced-analytics.jpg" style="width: 100%; border-radius: 5px; margin: 1rem 0;">
                <p style="color: white;font-size: 1.2rem;">
                    Utilizing ML algorithms to analyze transaction patterns and detect fraudulent activities.
                    <br><u><b>Click me to learn more</b></u>
                </p>
            </div> </a>
        """, unsafe_allow_html=True)

    with col5:
        st.markdown("""
                    <a href="https://www.fraud.com/post/strong-customer-authentication" target="_blank" style="text-decoration: none;">
            <div class="custom-card">
                <h3 style="color: white;">Customer Authentication</h3>
                <img src="https://swoopnow.com/wp-content/uploads/2020/07/User-Authentication_-Understanding-the-Basics-Top-Tips.jpg" style="width: 100%; border-radius: 5px; margin: 1rem 0;">
                <p style="color: white;font-size: 1.2rem;">
                    Methods like passwords, two-factor authentication, OTPs and AI-powered risk-based authentication.
                    <br><u><b>Click me to learn more</b></u>
                </p>
            </div> </a>
        """, unsafe_allow_html=True)

        
    st.markdown('''<p style="font-size: 20px; line-height: 1.8; text-align: center; color: #007BFF;">
            Start your journey toward secure digital transactions today!
        </p>''', unsafe_allow_html=True)
    


elif selected == "Single Transaction":
    # Layout with columns for left-aligned inputs and right-aligned button/results
    col0,col1 ,col2 = st.columns([1,2, 1])  # First column is wider, second column is for right alignment

    # Left column: Input fields
    with col1:
        
        st.markdown('<h2 class="section-title">Single Transaction Fraud Detection</h2>', unsafe_allow_html=True)
        st.session_state.transaction_type = st.selectbox("Transaction Type", options=list(transaction_types.keys()), index=list(transaction_types.keys()).index(st.session_state.transaction_type))
        st.session_state.transaction_amount = st.number_input("Transaction Amount", min_value=0.0, value=st.session_state.transaction_amount, help="Amount should be greater than 0.")
        st.session_state.old_balance = st.number_input("Old Balance of Origin Account", min_value=0.0, value=st.session_state.old_balance)
        st.session_state.new_balance = st.number_input("New Balance of Origin Account", min_value=0.0, value=st.session_state.new_balance)

    # Right column: Button and Results
    # with col2:
        # Predict button on the right
        col3, col4 = st.columns([1, 1])  # First column is wider, second column is for right alignment
        with col3:
            # import streamlit as st

            # # Define the HTML and CSS for the button
            # button_html = """
            # <div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
            #     <button class="animated-button">
            #         <svg viewBox="0 0 24 24" class="arr-2" xmlns="http://www.w3.org/2000/svg">
            #             <path
            #                 d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z"
            #             ></path>
            #         </svg>
            #         <span class="text">Predict</span>
            #         <span class="circle"></span>
            #         <svg viewBox="0 0 24 24" class="arr-1" xmlns="http://www.w3.org/2000/svg">
            #             <path
            #                 d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z"
            #             ></path>
            #         </svg>
            #     </button>
            # </div>

            # <style>
            # /* From Uiverse.io by gharsh11032000 */
            # .animated-button {
            # transform:translate(-30px,-400px);
            # position: relative;
            # display: flex;
            # align-items: center;
            # gap: 4px;
            # padding: 16px 36px;
            # border: 4px solid;
            # border-color: transparent;
            # font-size: 20px;
            # background-color: inherit;
            # border-radius: 100px;
            # font-weight: 600;
            # color: greenyellow;
            # box-shadow: 0 0 0 2px greenyellow;
            # cursor: pointer;
            # overflow: hidden;
            # transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
            # scale:0.85;
            # width:180%;
            # }

            # .animated-button svg {
            # position: absolute;
            # width: 24px;
            # fill: greenyellow;
            # z-index: 9;
            # transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
            # }

            # .animated-button .arr-1 {
            # right: 16px;
            # }

            # .animated-button .arr-2 {
            # left: -25%;
            # }

            # .animated-button .circle {
            # position: absolute;
            # top: 50%;
            # left: 50%;
            # transform: translate(-50%, -50%);
            # width: 20px;
            # height: 20px;
            # background-color: greenyellow;
            # border-radius: 50%;
            # opacity: 0;
            # transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
            # }

            # .animated-button .text {
            # position: relative;
            # z-index: 1;
            # transform: translateX(-12px);
            # transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
            # }

            # .animated-button:hover {
            # box-shadow: 0 0 0 12px transparent;
            # color: #212121;
            # # border-radius: 12px;
            # }

            # .animated-button:hover .arr-1 {
            # right: -25%;
            # }

            # .animated-button:hover .arr-2 {
            # left: 16px;
            # }

            # .animated-button:hover .text {
            # transform: translateX(12px);
            # }

            # .animated-button:hover svg {
            # fill: #212121;
            # }

            # .animated-button:active {
            # scale: 0.95;
            # box-shadow: 0 0 0 4px greenyellow;
            # }

            # .animated-button:hover .circle {
            # width: 400px;
            # height: 400px;
            # opacity: 1;
            # }
            # </style>
            # """

            # Render the HTML in Streamlit
            # st.markdown(button_html, unsafe_allow_html=True)
            
            prediction_text="Not Fraud"
            
            if st.button("Predict", key="predict_single"):
                if st.session_state.transaction_type == "Select Transaction Type":
                    st.error("Transaction type not selected! Please choose a valid transaction type.")
                elif st.session_state.transaction_amount <= 0:
                    st.error("Transaction amount must be greater than 0.")
                else:
                    # Create input data for the prediction
                    input_data = pd.DataFrame({
                        'type': [transaction_types[st.session_state.transaction_type]],
                        'amount': [st.session_state.transaction_amount],
                        'oldbalanceOrg': [st.session_state.old_balance],
                        'newbalanceOrig': [st.session_state.new_balance]
                    })
                    
                    # Predict the result
                    prediction = log_reg_loaded.predict(input_data)
                    prediction_text = "Fraud" if prediction[0] == "Fraud" else "Not Fraud"
                    color_class = "fraud" if prediction_text == "Fraud" else "not-fraud"
                    
                    # Display prediction result
                    st.markdown(f"""
                    <div class="highlight-box {color_class}">
                        <strong>Prediction: {prediction_text}</strong>
                    </div>
                    """, unsafe_allow_html=True)

                    
                    # Log the transaction
                    transaction = pd.DataFrame([[st.session_state.transaction_type, st.session_state.transaction_amount, st.session_state.old_balance, st.session_state.new_balance, prediction_text]],
                                            columns=["Transaction Type", "Amount", "Old Balance", "New Balance", "Prediction"])
                    transaction.to_csv(history_path, mode='a', header=False, index=False)
        
                
                    
                    
        with col4:
            import streamlit as st

            # Define the HTML and CSS for the button
            # button_html = """
            # <div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
            #     <button class="button">
            #         <svg viewBox="0 0 448 512" class="svgIcon"><path d="M135.2 17.7L128 32H32C14.3 32 0 46.3 0 64S14.3 96 32 96H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H320l-7.2-14.3C307.4 6.8 296.3 0 284.2 0H163.8c-12.1 0-23.2 6.8-28.6 17.7zM416 128H32L53.2 467c1.6 25.3 22.6 45 47.9 45H346.9c25.3 0 46.3-19.7 47.9-45L416 128z"></path></svg>
            #     </button>
            # </div>

            # <style>
            # /* From Uiverse.io by vinodjangid07 */
            # .button {
            # # transform: translateY(-900px);
            # transform: translate(0px,-340px);
            # width: 300px;
            # height: 60px;
            # border-radius: 50px ;
            # background-color: rgb(20, 20, 20);
            # border: none;
            # font-weight: 600;
            # display: flex;
            # align-items: center;
            # justify-content: center;
            # box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.164);
            # cursor: pointer;
            # transition-duration: .3s;
            # overflow: hidden;
            # position: relative;
            # border:2px solid white;
            # }

            # .svgIcon {
            # width: 12px;
            # scale:1.2;
            # transition-duration: .3s;
            # }

            # .svgIcon path {
            # fill: white;
            # }

            # .button:hover {
            # # width: 140px;
            # border-radius: 50px;
            # transition-duration: .3s;
            # background-color: rgb(255, 69, 69);
            # align-items: center;
            # border:None;
            # }

            # .button:hover .svgIcon {
            # scale:1;
            # width: 50px;
            # transition-duration: .3s;
            # transform: translateY(60%);
            # }

            # .button::before {
            # position: absolute;
            # top: -20px;
            # content: "Delete";
            # color: white;
            # transition-duration: .3s;
            # font-size: 2px;
            # }

            # .button:hover::before {
            # font-size: 13px;
            # opacity: 1;
            # transform: translateY(30px);
            # transition-duration: .3s;
            # }
            
            # </style>
            # """

            # Render the HTML in Streamlit
            # st.markdown(button_html, unsafe_allow_html=True)
                # Reset button
            if st.button("Reset", key="reset_button"):
                # Reset the form fields by clearing session state values
                st.session_state.transaction_type = "Select Transaction Type"
                st.session_state.transaction_amount = 0.0
                st.session_state.old_balance = 0.0
                st.session_state.new_balance = 0.0
                # st.experimental_rerun()  # Rerun the app to reflect changes
    col5,col6,col7=st.columns([2,5,2])
    with col6:
        if prediction_text == "Fraud":
            # Custom CSS to move the form up
            st.markdown("""
                <style>
                    .fraud-form-container {
                        position: relative;
                        transform: translateY(-300px);  /* Move the form upwards */
                    }
                </style>
            """, unsafe_allow_html=True)
            
            with st.form(key="fraud_report_form"):
                st.markdown("<div class='fraud-form-container'>", unsafe_allow_html=True)  # Apply custom class for positioning
                
                st.markdown("### Fraud Report Form")

                # Input fields
                name = st.text_input("Name")
                account_number = st.text_input("Account Number")
                description = st.text_area("Detailed Description of Fraud")

                # Submit and reset buttons
                submit_button = st.form_submit_button("Submit")
                reset_button = st.form_submit_button("Reset")

                if submit_button:
                    if name and account_number and description:
                        st.success("Fraud report submitted successfully!")
                        # Optionally log the fraud report or store it in a file
                    else:
                        st.error("All fields are required!")

                if reset_button:
                    st.experimental_rerun()  # Reset the form if needed

                st.markdown("</div>", unsafe_allow_html=True)  # Closing the custom class div

    

elif selected == "Bulk Upload":
    st.markdown('<h2 class="section-title">Bulk Transaction Fraud Detection</h2>', unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Upload a CSV file", type="csv")

    if uploaded_file:
        transactions = pd.read_csv(uploaded_file)
        required_columns = ["Transaction Type", "Amount", "Old Balance", "New Balance"]

        # Check if required columns are present
        if all(column in transactions.columns for column in required_columns):
            # Map 'Transaction Type' to integer values for prediction
            transactions["Transaction Type"] = transactions["Transaction Type"].map(transaction_types)

            # Handle rows with invalid 'Transaction Type' (e.g., empty or unrecognized types)
            transactions = transactions[transactions["Transaction Type"].notna()]

            # Prepare the data for prediction
            input_data = transactions[required_columns].values  # Include 'Transaction Type'

            # Predict using the model
            predictions = log_reg_loaded.predict(input_data)

            # Map numeric predictions back to 'Fraud' or 'Not Fraud'
            transactions["Prediction"] = ["Fraud" if pred == "Fraud" else "Not Fraud" for pred in predictions]

            # Map 'Transaction Type' back to original values for display (reverse map)
            reverse_transaction_types = {v: k for k, v in transaction_types.items()}
            transactions["Transaction Type"] = transactions["Transaction Type"].map(reverse_transaction_types)

            # Display the results
            # Display metrics horizontally with custom HTML and CSS
            st.markdown(f"""
                <style>
                    .metrics-container {{
                        display: flex;
                        justify-content: space-around;
                        margin: 20px;
                    }}
                    .metric-box {{
                        width:400px;
                        margin:5opx;
                        background-color: #f0f2f6;
                        border: 1px solid #e6e9ef;
                        border-radius: 10px;
                        padding: 15px 20px;
                        text-align: center;
                        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                    }}
                    .metric-title {{
                        font-size: 16px;
                        font-weight: bold;
                        color: #333;
                        margin-bottom: 8px;
                    }}
                    .metric-value {{
                        font-size: 24px;
                        font-weight: bold;
                    }}
                    .total-transactions .metric-value {{
                        color: #007BFF; /* Blue for total */
                    }}
                    .fraud-transactions {{
                        background-color: lightcoral;
                        color: white;
                    }}
                    .not-fraud-transactions {{
                        background-color: lightgreen;
                        color: black;
                    }}
                </style>

                <div class="metrics-container">
                    <div class="metric-box total-transactions">
                        <div class="metric-title">Total Transactions</div>
                        <div class="metric-value">{len(transactions)}</div>
                    </div>
                    <div class="metric-box fraud-transactions">
                        <div class="metric-title">Fraud Transactions</div>
                        <div class="metric-value">{transactions["Prediction"].value_counts().get("Fraud", 0)}</div>
                    </div>
                    <div class="metric-box not-fraud-transactions">
                        <div class="metric-title">Not Fraud Transactions</div>
                        <div class="metric-value">{transactions["Prediction"].value_counts().get("Not Fraud", 0)}</div>
                    </div>
                </div>
            """, unsafe_allow_html=True)

            # Create two columns: left for table, right for metrics and chart
            col1, col2 = st.columns([2, 1])  # Adjust the proportions as needed

            # Left column: Show the results table
            with col1:
                st.dataframe(transactions.style.applymap(
                    lambda x: "background-color: lightcoral; color: white;" if x == "Fraud" else "background-color: lightgreen; color: black;",
                    subset=["Prediction"]
                ))

            # Right column: Show metrics and pie chart
            with col2:
                

                # Create pie chart
                labels = ["Fraud", "Not Fraud"]
                sizes = [transactions["Prediction"].value_counts().get("Fraud", 0), transactions["Prediction"].value_counts().get("Not Fraud", 0)]
                colors = ["lightcoral", "lightgreen"]
                fig, ax = plt.subplots()
                ax.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
                ax.axis("equal")  # Equal aspect ratio ensures the pie is drawn as a circle
                st.pyplot(fig)

            # Save the results to the history file
            transactions.to_csv(history_path, mode='a', header=False, index=False)
        else:
            st.markdown('<h2 class="error">"CSV must include columns: ["Transaction Type", "Amount", "Old Balance", "New Balance"]</h2>', unsafe_allow_html=True)

            
            # st.warning(f"CSV must include columns: ["Transaction Type", "Amount", "Old Balance", "New Balance"]")
        

elif selected == "Transaction History":
    st.markdown('<h2 class="section-title">Transaction History</h2>', unsafe_allow_html=True)

    history_path = "transactions_history.csv"  # Update the path accordingly

    if os.path.exists(history_path):
        history = pd.read_csv(history_path)
        # Display metrics horizontally with custom HTML and CSS
        st.markdown(f"""
            <style>
                .metrics-container {{
                    display: flex;
                    justify-content: space-around;
                    margin: 20px 0;
                }}
                .metric-box {{
                    width:400px;
                    background-color: #f0f2f6;
                    border: 1px solid #e6e9ef;
                    border-radius: 10px;
                    padding: 15px 20px;
                    text-align: center;
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                }}
                .metric-title {{
                    font-size: 16px;
                    font-weight: bold;
                    color: #333;
                    margin-bottom: 8px;
                }}
                .metric-value {{
                    font-size: 24px;
                    font-weight: bold;
                }}
                .total-transactions .metric-value {{
                    color: #007BFF; /* Blue for total */
                }}
                .fraud-transactions {{
                    background-color: lightcoral;
                    color: white;
                }}
                .not-fraud-transactions {{
                    background-color: lightgreen;
                    color: black;
                }}
            </style>

            <div class="metrics-container">
                <div class="metric-box total-transactions">
                    <div class="metric-title">Total Transactions</div>
                    <div class="metric-value">{len(history)}</div>
                </div>
                <div class="metric-box fraud-transactions">
                    <div class="metric-title">Fraud Transactions</div>
                    <div class="metric-value">{history["Prediction"].value_counts().get("Fraud", 0)}</div>
                </div>
                <div class="metric-box not-fraud-transactions">
                    <div class="metric-title">Not Fraud Transactions</div>
                    <div class="metric-value">{history["Prediction"].value_counts().get("Not Fraud", 0)}</div>
                </div>
            </div>
        """, unsafe_allow_html=True)

        # Create two columns for organizing layout
        col1, col2 = st.columns([2, 1])  # Adjust column widths as needed
        
        with col1:
            # Displaying the transaction history with colored predictions
            st.dataframe(history.style.map(
                lambda x: "background-color: lightcoral; color: white;" if x == "Fraud" else "background-color: lightgreen; color: black;",
                subset=["Prediction"]
            ))
        
        with col2:
            history_path = "transactions_history.csv"

            # Check if the file exists
            if os.path.exists(history_path):
                # Read the CSV file
                history = pd.read_csv(history_path)

                # Group the data by Transaction Type and Prediction (Fraud or Not Fraud)
                transaction_fraud_counts = history.groupby(['Prediction']).size()

                # Prepare data for the pie chart
                pie_data = transaction_fraud_counts

                # Create a figure and axis for a larger pie chart
                fig, ax = plt.subplots(figsize=(16, 16))  # Increased size further to make it larger

                # Define the colors for the pie chart (using a distinct color palette)
                colors = plt.cm.Paired.colors

                # Plot the pie chart with percentages displayed on the chart
                wedges, texts, autotexts = ax.pie(
                    pie_data, 
                    labels=pie_data.index, 
                    autopct='%1.1f%%', 
                    startangle=90, 
                    colors=["lightcoral", "lightgreen"],
                    wedgeprops={'edgecolor': 'black', 'linewidth': 1.5},  # Adds borders to the wedges for better visibility
                    pctdistance=0.75  # Moved percentage text a bit further from the center to avoid congestion
                )

                # Equal aspect ratio ensures the pie is drawn as a circle.
                ax.axis('equal')

                # Set title for the chart
                # ax.set_title('Distribution of Fraud and Not Fraud for Each Transaction Type', fontsize=20)

                # Customize the labels' appearance
                for text in texts + autotexts:
                    text.set_fontsize(60)
                    text.set_fontweight('bold')

                # Adding a legend to differentiate between Fraud and Not Fraud
                ax.legend(
                    labels=pie_data.index, 
                    loc="upper left", 
                    fontsize=14, 
                    title="Transaction Type and Fraud Status",
                    bbox_to_anchor=(1.2, 1)  # Move legend outside of the pie chart for better spacing
                )

                # Display the pie chart using Streamlit
                st.pyplot(fig)
            # history_path = "transactions_history.csv"

            # # Check if the file exists
            # if os.path.exists(history_path):
            #     # Read the CSV file
            #     history = pd.read_csv(history_path)

            #     # Group the data by Transaction Type and Prediction (Fraud or Not Fraud)
            #     transaction_fraud_counts = history.groupby(['Transaction Type', 'Prediction']).size().unstack(fill_value=0)

            #     # Prepare data for the pie chart
            #     pie_data = transaction_fraud_counts.stack()

            #     # Create a figure and axis for a larger pie chart
            #     fig, ax = plt.subplots(figsize=(14, 14))  # Increased size further to make it larger

            #     # Define the colors for the pie chart (using a distinct color palette)
            #     colors = plt.cm.Paired.colors

            #     # Plot the pie chart with percentages displayed on the chart
            #     wedges, texts, autotexts = ax.pie(
            #         pie_data, 
            #         labels=pie_data.index, 
            #         autopct='%1.1f%%', 
            #         startangle=90, 
            #         colors=colors,
            #         wedgeprops={'edgecolor': 'black', 'linewidth': 1.5},  # Adds borders to the wedges for better visibility
            #         pctdistance=0.85  # Moves percentage text closer to the edge
            #     )

            #     # Equal aspect ratio ensures the pie is drawn as a circle.
            #     ax.axis('equal')

            #     # Set title for the chart
            #     ax.set_title('Distribution of Fraud and Not Fraud for Each Transaction Type', fontsize=16)

            #     # Customize the labels' appearance
            #     for text in texts + autotexts:
            #         text.set_fontsize(12)
            #         text.set_fontweight('bold')

            #     # Adding a legend to differentiate between Fraud and Not Fraud
            #     ax.legend(
            #         labels=pie_data.index, 
            #         loc="upper left", 
            #         fontsize=16, 
            #         title="Transaction Type and Fraud Status",
            #         bbox_to_anchor=(1.2, 1)  # Move legend outside of the pie chart
            #     )
                
            #     # Display the pie chart using Streamlit
            #     st.pyplot(fig)
            # history_path = "transactions_history.csv"

            # # Check if the file exists
            # if os.path.exists(history_path):
            #     # Read the CSV file
            #     history = pd.read_csv(history_path)

            #     # Count the occurrences of each transaction type
            #     transaction_counts = history['Transaction Type'].value_counts()

            #     # Create a pie chart
            #     fig, ax = plt.subplots()
            #     ax.pie(transaction_counts, labels=transaction_counts.index, autopct='%1.1f%%', startangle=90, colors=plt.cm.Paired.colors)
            #     ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

            #     # Set title
            #     ax.set_title('Transaction Types Distribution')

            #     # Display the pie chart using Streamlit
            #     st.pyplot(fig)

    else:
        st.write("No transaction history available.")


elif selected == "About":
    # st.markdown('<h2 class="section-title">About Online Payment Fraud Detection</h2>', unsafe_allow_html=True)
    # st.markdown("""
    # Fraudulent activities in online payments are on the rise due to the rapid growth of digital transactions. 
    # Cybercriminals use various techniques, such as phishing, identity theft, and malware, to exploit vulnerabilities 
    # in online payment systems. Protecting users and businesses from such fraud requires advanced tools and awareness.
    # """)
    
    # # Add an image related to fraud detection
    # st.markdown('<img class="img" style="margin-left:100px;" src="https://5logistics.com/wp-content/uploads/Fraud-1.jpg" alt="Fraud Detection">', unsafe_allow_html=True)
        
    # st.markdown("""
    # ### Features of Fraud Detection:
    
    # - **Real-Time Analysis:** 
    #   Fraudulent transactions are identified as they happen, minimizing potential losses. Real-time monitoring uses algorithms to detect anomalies in payment patterns.
    # - **Machine Learning:** 
    #   Leveraging historical data, machine learning models can identify patterns and predict fraudulent behavior. These systems improve over time, adapting to new threats.
    # - **Multi-Layer Security:** 
    #   Modern fraud detection systems combine multiple security protocols, including encryption, tokenization, and biometric authentication, to ensure robust protection.
    # - **Risk Scoring:** 
    #   Transactions are assigned risk scores based on factors like geolocation, transaction amount, and device used, helping to identify suspicious activities.
    # - **Behavioral Analytics:** 
    #   Monitoring user behavior, such as login patterns and spending habits, to flag deviations that may indicate fraud.
    # """)
    
    # # Add an image for machine learning or analytics
    # st.markdown('<img style="margin-left:100px;margin-right:auto;" src="https://www.digipay.guru/static/24fb1b1f75d3f9ddb1373c2e1cebbd75/16546/online-payment-security-Image_04.png" alt="Fraud Detection">', unsafe_allow_html=True)
    
    # st.markdown("""
    # ### Tips for Staying Protected During Online Transactions:
    # - **Verify Website Security:** 
    #   - Only transact on websites with HTTPS protocols. Look for a padlock icon in the browser's address bar.
    #   - Avoid using public Wi-Fi for online transactions unless you're connected to a trusted VPN.
    # - **Enable Multi-Factor Authentication (MFA):**
    #   - Add an extra layer of security by requiring a one-time password (OTP) or biometric authentication alongside your login credentials.
    # - **Keep Devices Updated:**
    #   - Regularly update your operating system, browser, and payment apps to patch known vulnerabilities.
    # - **Monitor Bank Statements:**
    #   - Review your bank statements and transaction history regularly to detect unauthorized activities early.
    # - **Avoid Phishing Scams:**
    #   - Be cautious of emails, messages, or calls requesting sensitive information. Cybercriminals often pose as legitimate entities.
    # - **Use Virtual Cards or Wallets:** 
    #   - Where possible, use virtual debit/credit cards or digital wallets for online payments. These options provide an extra layer of protection by masking your actual card details.
    # - **Educate Yourself and Others:** 
    #   - Stay informed about common fraud techniques, such as skimming, spoofing, and account takeover fraud, to recognize red flags.
    # """)

    # # Add an image related to online security or phishing
    # st.markdown('<img style="height:400px;width:600px;" src="https://pbsorg.siuat.visa.com/content/dam/financial-literacy/practical-business-skills/images/non-card/types-of-fraud-graphic.jpg" alt="Fraud Detection">', unsafe_allow_html=True)

    
    # st.markdown("""
    # ### Common Types of Online Payment Fraud:
    # - **Phishing Attacks:**
    #   Fraudsters trick users into providing login credentials or credit card information through fake websites or emails.
    # - **Card-Not-Present (CNP) Fraud:**
    #   Unauthorized transactions occur using stolen card details during online payments.
    # - **Man-in-the-Middle (MitM) Attacks:**
    #   Hackers intercept communication between the user and the payment system to steal sensitive information.
    # - **Account Takeover:**
    #   Cybercriminals gain access to user accounts and initiate fraudulent transactions.
    # - **Chargeback Fraud:**
    #   Customers falsely claim a legitimate transaction was unauthorized to receive a refund.
    # """)

    # st.markdown('<img src="https://blogimage.vantagefit.io/vfitimages/2021/06/MENTEL-HEALTH-AWARNESS-CELEBRATION--1.png" alt="Fraud Detection">', unsafe_allow_html=True)


    # st.markdown("""
    # ### Raising Awareness:
    # - **Use Reputable Services:**
    #   Opt for well-known and trusted payment gateways.
    # - **Educate Your Network:** 
    #   Share tips and resources with friends and family to promote safer online transaction habits.
    # - **Report Suspicious Activity:** 
    #   Inform your bank or payment service provider immediately if you notice any unusual activity.
    # - **Leverage Fraud Detection Tools:** 
    #   Use services or tools that proactively monitor transactions and send alerts for suspicious activities.

    # By adopting these practices and leveraging advanced fraud detection tools, you can significantly minimize the risk of falling victim to online payment fraud.
    # """)
    st.markdown('''
                <div class="morphism-opacity">
                <h2 class="section-title">About Online Payment Fraud Detection</h2>
                </div>
                ''', unsafe_allow_html=True)
    st.markdown("""
    <div class="morphism-opacity">
    <p>Fraudulent activities in online payments are on the rise due to the rapid growth of digital transactions. 
    Cybercriminals use various techniques, such as phishing, identity theft, and malware, to exploit vulnerabilities 
    in online payment systems. Protecting users and businesses from such fraud requires advanced tools and awareness.
    </p></div>
    """, unsafe_allow_html=True)

    # Create two columns
    col1, col2 = st.columns([1, 1])

    with col2:
        # Add an image related to fraud detection
        st.markdown('<img class="img" style="transform:translateY(18px);" src="https://kycaid.com/blog/content/images/2023/11/3808762.jpg" alt="Fraud Detection">', unsafe_allow_html=True)

    with col1:
        # Add text in the second column
        st.markdown("""
                    <div class="morphism-opacity">
            <h3>Features of Fraud Detection:</h3>
            </div>
            <div class="morphism-opacity">
            <ul>
                <li>Real-Time Analysis: Fraudulent transactions are identified as they happen, minimizing potential losses. Real-time monitoring uses algorithms to detect anomalies in payment patterns.</li>
                <li>Machine Learning: Leveraging historical data, machine learning models can identify patterns and predict fraudulent behavior. These systems improve over time, adapting to new threats.</li>
                <li>Multi-Layer Security: Modern fraud detection systems combine multiple security protocols, including encryption, tokenization, and biometric authentication, to ensure robust protection.</li>
                <li>Risk Scoring: Transactions are assigned risk scores based on factors like geolocation, transaction amount, and device used, helping to identify suspicious activities.</li>
                <li>Behavioral Analytics: Monitoring user behavior, such as login patterns and spending habits, to flag deviations that may indicate fraud.</li>
            </ul>
            </div>
        """, unsafe_allow_html=True)


    

    # Create a new section for tips for staying protected during online transactions
    # st.markdown(""" Tips for Staying Protected During Online Transactions:""")

    # Create two more columns for this section
    col3, col4 = st.columns([1, 1])

    with col3:
        st.markdown("""
            <div class="morphism-opacity">
            <h3>Tips for Staying Protected During Online Transactions:</h3>
            <div>""", unsafe_allow_html=True);
        st.markdown("""
            <div class="morphism-opacity">
            <ul>
                <li>Verify Website Security:
                    <ul>
                        <li>Only transact on websites with HTTPS protocols. Look for a padlock icon in the browser's address bar.</li>
                        <li>Avoid using public Wi-Fi for online transactions unless you're connected to a trusted VPN.</li>
                    </ul>
                </li>
                <li>Enable Multi-Factor Authentication (MFA):
                    <ul>
                        <li>Add an extra layer of security by requiring a one-time password (OTP) or biometric authentication alongside your login credentials.</li>
                    </ul>
                </li>
                <li>Keep Devices Updated:
                    <ul>
                        <li>Regularly update your operating system, browser, and payment apps to patch known vulnerabilities.</li>
                    </ul>
                </li>
                <li>Monitor Bank Statements:
                    <ul>
                        <li>Review your bank statements and transaction history regularly to detect unauthorized activities early.</li>
                    </ul>
                </li>
                <li>Avoid Phishing Scams:
                    <ul>
                        <li>Be cautious of emails, messages, or calls requesting sensitive information. Cybercriminals often pose as legitimate entities.</li>
                    </ul>
                </li>
            </ul>
            </div>
        """, unsafe_allow_html=True)


    with col4:
        # Add an image for machine learning or analytics
        st.markdown('<img style="margin-left:10px;margin-right:auto;transform:translateY(160px);" src="https://diro.io/wp-content/uploads/2022/06/payment-gateway.jpg" alt="Fraud Detection">', unsafe_allow_html=True)
        

    col7, col8 = st.columns([1, 1])

    with col7:
        # Raising awareness section
        st.markdown("""
                    <div class="morphism-opacity">
                    <h3>Raising Awareness:</h3>
                    </div>
                    """, unsafe_allow_html=True)

        st.markdown("""
            <div class="morphism-opacity">
            <ul>
                <li>Use Reputable Services:
                    Opt for well-known and trusted payment gateways.</li>
                <li>Educate Your Network:
                    Share tips and resources with friends and family to promote safer online transaction habits.</li>
                <li>Report Suspicious Activity:
                    Inform your bank or payment service provider immediately if you notice any unusual activity.</li>
                <li>Leverage Fraud Detection Tools:
                    Use services or tools that proactively monitor transactions and send alerts for suspicious activities.</li>
            </ul>
            </div>
            <div class="morphism-opacity">
            <p>By adopting these practices and leveraging advanced fraud detection tools, you can significantly minimize the risk of falling victim to online payment fraud.</p></div>
        """, unsafe_allow_html=True)


    with col8:
        st.markdown('<img style="transform:translateY(20px);" src="https://media.licdn.com/dms/image/D5612AQG21HcQ5ygS-A/article-cover_image-shrink_600_2000/0/1671779778905?e=2147483647&v=beta&t=PeaqxXlpYPkd7jZgFtWpNpjizxIWHrdqCel-NoJ4njg" alt="Fraud Detection">', unsafe_allow_html=True)
    st.title("Feedback Form")

    # Add a short description
    st.write("We would love to hear your feedback! Please fill out the form below:")

    # Feedback Form
    with st.form(key='feedback_form'):
        # Collect user information (Optional)
        name = st.text_input("Your Name")
        email = st.text_input("Your Email (Optional)")

        # Collect feedback rating
        rating = st.radio("How would you rate your experience?", [1, 2, 3, 4, 5])

        # Collect detailed feedback
        feedback = st.text_area("Please provide your detailed feedback:")

        # Add a submit button
        submit_button = st.form_submit_button("Submit Feedback")

    # After the form is submitted
    if submit_button:
        if name and feedback:
            # Display the user's input (for demo purposes)
            st.write(f"Thank you for your feedback, {name}!")
            st.write(f"Rating: {rating}/5")
            st.write(f"Feedback: {feedback}")
            if email:
                st.write(f"Email: {email}")
        else:
            st.warning("Please make sure you provide both your name and feedback.")
    

            